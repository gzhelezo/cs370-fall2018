// CS370 - Fall 2018
// Assign02 - Rollin Train

#ifdef OSX
	#include <GLUT/glut.h>
#else
	#include <GL/glew.h>
	#include <GL/glut.h>
#endif
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

// Shader file utility functions
#include "shaderutils.h"
#include "train.h"

// Shader files
GLchar* vertexFile = "basicvert.vs";
GLchar* fragmentFile = "basicfrag.fs";

// Shader objects
GLuint shaderProg;

#define RAD2DEG (180.0f/3.14159f)
#define DEG2RAD (3.14159f/180.0f)

// View modes
#define ORTHOGRAPHIC 0
#define PERSPECTIVE 1
int proj = ORTHOGRAPHIC;

// Component indices
#define X 0
#define Y 1
#define Z 2

// Display list identifiers


// Define globals
GLfloat eye[3] = { 2.0f, 2.0f, 2.0f };
GLfloat at[3] = { 0.0f, 0.0f, 0.0f };
GLfloat up[3] = { 0.0f, 1.0f, 0.0f };

// Function Prototypes
void display();
void render_Scene();
void keyfunc(unsigned char key, int x, int y);
void reshape(int w, int h);
void idlefunc();
void create_lists();

int main(int argc, char* argv[])
{
	// Initialize glut
	glutInit(&argc, argv);

	// Initialize window
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500,500);
	glutCreateWindow("RailRoad");

#ifndef OSX
	// Initialize GLEW - MUST BE DONE AFTER CREATING GLUT WINDOW
	glewInit();
#endif

	// Define callbacks
	glutDisplayFunc(display);
	glutKeyboardFunc(keyfunc);
	glutIdleFunc(idlefunc);
	glutReshapeFunc(reshape);

	// Create display lists
	create_lists();

	// Set background color
	glClearColor(1.0f,1.0f,1.0f,1.0f);

	// Load shader programs
	shaderProg = load_shaders(vertexFile,fragmentFile);
	glUseProgram(shaderProg);

	// Start graphics loop
	glutMainLoop();

	return 0;
}

// Display callback
void display()
{
	// Reset background
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Set initial orthographic projection matrix
	if (proj == ORTHOGRAPHIC)
	{
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(-15.0, 15.0, -15.0, 15.0, -15.0, 15.0);

		// Set modelview matrix
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		// Set orthographic camera
		gluLookAt(eye[X], eye[Y], eye[Z], at[X], at[Y], at[Z], up[X], up[Y], up[Z]);
	}
	// Render scene
	render_Scene();

	// Flush buffer
	glFlush();

	// Swap buffers
	glutSwapBuffers();
}

// Scene render function
void render_Scene()
{

}

// Keyboard callback
void keyfunc(unsigned char key, int x, int y)
{
	// Toggle projection mode
	if (key == 'o')
	{
		proj = ORTHOGRAPHIC;
	}
	else if (key == 'p')
	{
		proj = PERSPECTIVE;
	}

	// Quit program
	if (key==27)
	{
		exit(0);
	}

	// Redraw scene
	glutPostRedisplay();
}

// Reshape callback
void reshape(int w, int h)
{
	// Set new screen extents
	glViewport(0,0,w,h);
}

// Idle callback
void idlefunc()
{

}

// Routine to create display lists
void create_lists()
{

}
